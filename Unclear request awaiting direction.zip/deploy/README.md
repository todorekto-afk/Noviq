# noviqstudios.nl

Static site for Noviq Studios, ready for GitHub Pages.

- `index.html` — home · `services.html` · `work.html` · `process.html` · `faq.html` · `proposal.html`
- `privacy.html` · `terms.html` · `cookies.html` · `refund.html` — policy pages
- `SiteNav.dc.html`, `SiteFooter.dc.html`, `SiteChat.dc.html` — shared header, footer and assistant, loaded by every page
- `support.js` — component runtime; must sit next to the pages
- `fonts/` — self-hosted Outfit, DM Sans, JetBrains Mono (no third-party font requests)
- `img/` — logo mark and Haven Physio concept screenshots
- `CNAME` — custom domain · `.nojekyll` — serve files as-is

## Before going live

Replace `[Your full legal name]`, `[KvK number]`, `[14]` days and `[your district/city]` in the policy pages and the footer.

## Deploy

Commit the contents of this folder to the repository root on the branch GitHub Pages serves.
Everything is relative, so it also opens straight from disk.
